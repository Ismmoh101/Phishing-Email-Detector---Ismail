# Phishing Email Detector
Simple ML-based phishing detection API using FastAPI.
