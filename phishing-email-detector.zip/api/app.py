from fastapi import FastAPI, Request
from pydantic import BaseModel
import joblib

class EmailText(BaseModel):
    text: str

app = FastAPI()

@app.post('/predict')
def predict(email: EmailText):
    # Dummy logic for demonstration
    if 'urgent' in email.text.lower():
        return {'phishing': True}
    return {'phishing': False}
